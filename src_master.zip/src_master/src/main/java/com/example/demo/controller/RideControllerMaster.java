package com.example.demo.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.service.RideService;

@Controller
public class RideControllerMaster {
	Logger log=Logger.getAnonymousLogger();
	@Autowired
	private RideService service;
	
	
	
	@RequestMapping("/displayAllBooking")
	public ModelAndView displayAllBooking(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();	
		int  user_id=Integer.parseInt(request.getParameter("user_id"));
		List<Object[]> userRideDetails = service.viewAllUserRides(user_id);
		log.info("values recieved from form ");
	
			mv.setViewName("viewBooking.jsp");
			log.info("login is suceess");
			mv.addObject("userRideDetails", userRideDetails);
	
		return mv;
		
		
		/*
		 * log.info("entered into displayAllBookingflow "); ModelAndView mv=new
		 * ModelAndView(); User user=new User(); String
		 * user_id=request.getParameter("user_id");
		 * 
		 * RestTemplate temp=new RestTemplate(); String
		 * url="http://localhost:8080/ViewAllBooking/"+user_id; log.info(url);
		 * 
		 * temp.getForObject(url,String.class); mv.setViewName("viewBooking.jsp");
		 * mv.addObject("userRideDetails", user); return mv;
		 */
	}
	
	@RequestMapping("/insertRide")
	public ModelAndView insertRideMS(HttpServletRequest request,HttpServletResponse response) {
		log.info("entered into the regsiter master buddy flow ");
		ModelAndView mv=new ModelAndView();
		String pickup_location=request.getParameter("pickup_location");
		String destination=request.getParameter("destination");
		String ride_date_time=request.getParameter("ride_date_time");
		String fare=request.getParameter("fare");
		String driver_id=request.getParameter("driver_id");
		String user_id=request.getParameter("user_id");
		RestTemplate temp=new RestTemplate();
		String url="http://localhost:8080/bookRide/"+pickup_location+"/"+destination+"/"+ride_date_time+"/"+fare+"/"+user_id+"/"+driver_id;
		log.info(url);
		temp.getForObject(url,String.class);
		mv.setViewName("displayRides.jsp");
		mv.addObject("user_id", user_id);

		return mv;	
	}


}
