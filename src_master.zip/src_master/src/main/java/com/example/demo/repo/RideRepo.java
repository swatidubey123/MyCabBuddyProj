package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.pojo.Ride;

public interface RideRepo extends JpaRepository<Ride, Integer>  {
	
	
		String query1 = "SELECT r.ride_id,r.ride_date_time,r.pickup_location,r.destination,d.driver_name from Ride r,Drivers d,User u where r.driver_id = d.driver_id  AND u.user_id =?1 ";

		@Query(query1)
		public List<Object[]> viewAllRides(int user_id);

		
}
