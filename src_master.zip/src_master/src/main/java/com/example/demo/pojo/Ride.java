package com.example.demo.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class Ride {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ride_id;
    //private int user_id;
    private int driver_id;
    private String pickup_location;
    private String destination;
    private String ride_date_time;
    private int fare;
    
   
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="did", referencedColumnName = "driver_id" )
    private Drivers driver;

     
}

