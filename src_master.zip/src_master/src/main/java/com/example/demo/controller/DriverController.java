package com.example.demo.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.pojo.Drivers;
import com.example.demo.service.DriverService;
@Controller
public class DriverController {
	
	Logger log=Logger.getAnonymousLogger();
	@Autowired
	private DriverService service;
	
	

	@RequestMapping("/getAllDrivers")
	public ModelAndView registerms(HttpServletRequest request,HttpServletResponse response) {
		log.info("entered into the getalldriver master  ");
		ModelAndView mv=new ModelAndView();
		
		/*RestTemplate temp=new RestTemplate();
		
		 * String url="http://localhost:8080/getAllDriversClient"; log.info(url);
		 * temp.getForObject(url,String.class);
		 * 
		 */
		List<Drivers> list=service.findDrivers();
		mv.setViewName("bookCab.jsp");
		mv.addObject("list", list);
		

		return mv;	
	}



}
