package com.example.demo.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.pojo.User;
import com.example.demo.repo.UserRepo;


@Controller

public class UserController {
	Logger log=Logger.getAnonymousLogger();
	@Autowired
	private UserRepo repo;
	
	
	@RequestMapping("/")
	public ModelAndView defaultpage(HttpServletRequest request,HttpServletResponse response) {
		log.info("entered into the / request");
		ModelAndView mv=new ModelAndView();	
		mv.setViewName("login.jsp");	
		log.info("went to login.jsp page ");
		return mv;
		
	}
	
	@RequestMapping("/login")
	public ModelAndView loginRequest(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();	
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		log.info("values recieved from form ");
		User user=repo.findbynameandpassword(name, password);
		if(user!=null) {
			mv.setViewName("display.jsp");
			log.info("login is suceess");
			mv.addObject("user", user);
		}
		else {
			mv.setViewName("fail.jsp");
			log.info("login failed");
		}
		
		return mv;
		
	}

	@RequestMapping("/register")
	public ModelAndView registerms(HttpServletRequest request,HttpServletResponse response) {
		log.info("entered into the regsiter master buddy flow ");
		ModelAndView mv=new ModelAndView();
		User user=new User();
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String phno=request.getParameter("phno");
		String userType=request.getParameter("userType");
		RestTemplate temp=new RestTemplate();
		String url="http://localhost:8080/registerms/"+name+"/"+password+"/"+email+"/"+phno+"/"+userType;
		log.info(url);
		
		temp.getForObject(url,String.class);
		mv.setViewName("displayRegister.jsp");
		mv.addObject("user", user);
		return mv;	
	}



	@GetMapping("/getAllusers")
	public List<User> findAllusers(){
		return repo.findAll();
	}
	
	
	@GetMapping("/findbyemail/{email}")
	public List<User> finduser(@PathVariable String email)
	{
		return repo.findByEmail(email);
	}
	
	@GetMapping("/findbyname/{name}")
	public List<User> finduserByName(@PathVariable String name)
	{
		return repo.findByName(name);
	}
	
	@DeleteMapping("/cancel/{user_id}")
	public List<User> cancelregistartion(@PathVariable int user_id){
		repo.deleteById(user_id);
		return repo.findAll();
	}
}
