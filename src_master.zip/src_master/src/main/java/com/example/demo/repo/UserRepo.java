package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.pojo.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	
	 List<User> findByEmail(String email);
	 List<User> findByName(String name);
	 String query="select user from User user where user.name=?1 and user.password=?2";
		@Query(query)
	 public User findbynameandpassword(String name,String password);
	 
	 
	//get the teacher name of a student with some course name
	/*
	 * String
	 * query1="select sct.name from Student s join s.courses sc join sc.teachers sct where s.name=?1"
	 * ;
	 * 
	 * @Query(query1) public List<String> getTeacher(String studentname);
	 * 
	 * // with a student name get the courses
	 * 
	 * String
	 * query2="select sc.name from Student s join s.courses sc where s.name=?1";
	 * 
	 * @Query(query2) public List<String> getCourses(String studentname); //with a
	 * course name and student name -teacher name
	 * 
	 */
}
