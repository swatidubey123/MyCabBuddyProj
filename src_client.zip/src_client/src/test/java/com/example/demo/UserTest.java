package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.controller.UserController;
import com.example.demo.pojo.User;


@SpringBootTest
class UserTest {
	@Autowired
   UserController uc;
	@Test
	public void insertUserTest() {
		User user=new User();
		user.setEmail("suhan@z.com");
		user.setName("suhan");
		user.setPassword("suhan");
		user.setUserType("admin");
		user.setPhno("9189754");
		
		//assertNotNull(uc.register(user));
		
		}
	@Test
	public void deleteUser() {
	//assertEquals("deleted id of "+4,uc.cancelregistartion(4));


}
}
