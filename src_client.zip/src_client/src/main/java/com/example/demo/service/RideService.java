package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.Ride;
import com.example.demo.pojo.User;
import com.example.demo.repo.RideRepo;

@Service
public class RideService {
	@Autowired
	RideRepo repo;
	
	
	//insert
		public Ride insert(Ride e) {
			return repo.save(e);
		}
		//insertall
			public List<Ride> insertall(List<Ride> rides){
				return repo.saveAll(rides);
			}
			
			/*
			 * public List<Object[]> findbyuserId(int user_id){ return
			 * repo.findbyuserId(user_id); }
			 */
			
			
			public String delete(int id) {
				repo.deleteById(id);
				return "deleted succefully";
				
			}
			
			/*
			 * public List<Object[]> viewAllUserRides(User user){ int
			 * user_id=user.getUser_id(); return repo.viewAllRides(user_id); }
			 */
			

			public List<Ride> getall(){
				return repo.findAll();
				}
			//update 
			//update                          //new value
				public Ride updateRide(Ride r) {
					Ride ride=repo.findById(r.getRide_id()).orElse(null);
					
				/* ee--> {
			        "empno": 10,
			        "empname": "swati vivek",
			        "phono": "1234566"
			    }*/
				ride.setDestination(ride.getDestination());	
				ride.setRide_date_time(ride.getRide_date_time());
				ride.setPickup_location(ride.getPickup_location());
				
				return repo.save(ride);
					
				}

			//getbyid 
			//service 
			public Optional<Ride> getbyId(int ride_id) {
					return repo.findById(ride_id);
				}
			
			public void deleteById(int id) {
				repo.deleteById(id);
			}


		
		

}
