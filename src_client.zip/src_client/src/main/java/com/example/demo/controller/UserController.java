package com.example.demo.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Drivers;
import com.example.demo.pojo.User;
import com.example.demo.repo.UserRepo;


@Controller


public class UserController {
	Logger log=Logger.getAnonymousLogger();
	@Autowired
	private UserRepo repo;
	
	/*
	 * //insert
	 * 
	 * @ResponseBody
	 * 
	 * @RequestMapping("/insertUser") //JSON --> auto converted into the java object
	 * public User insert(@RequestBody User user) { return repo.save(user); }
	 */
	
		
		 @ResponseBody
		
		 @RequestMapping("/registerms/{name}/{password}/{email}/{phno}/{userType}")
		  public String register(HttpServletRequest request,HttpServletResponse
		  response,@PathVariable("name") String name,@PathVariable("password") String
		  password, @PathVariable("email") String email, @PathVariable("phno") String
		  phno, @PathVariable("userType") String userType) 
		 {
		  log.info("enetered into the register ms code ");
		  User user=new User();
		  user.setName(name); 
		  user.setPassword(password);
		  user.setEmail(email);
		  user.setPhno(phno); 
		  user.setUserType(userType);
		  repo.save(user); 
		  return "done";
		  
		  }
		 
	/*
	 * @GetMapping("/getAllusers") public List<User> findAllusers(){ return
	 * repo.findAll(); }
	 */
	
	/*
	 * @GetMapping("/findbyemail/{email}") public List<User> finduser(@PathVariable
	 * String email) { return repo.findByEmail(email); }
	 */
	
	/*
	 * @GetMapping("/findbyname/{name}") public List<User>
	 * finduserByName(@PathVariable String name) { return repo.findByName(name); }
	 */
	/*
	 * @DeleteMapping("/cancel/{user_id}") public List<User>
	 * cancelregistartion(@PathVariable int user_id){ repo.deleteById(user_id);
	 * return repo.findAll(); }
	 */
}
