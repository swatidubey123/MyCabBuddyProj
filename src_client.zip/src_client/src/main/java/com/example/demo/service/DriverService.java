package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.Drivers;
import com.example.demo.pojo.Ride;
import com.example.demo.repo.DriverRapo;

@Service
public class DriverService {
	@Autowired
	DriverRapo repo;
	
	//insert
			public Drivers insert(Drivers driver) {
				return repo.save(driver);
			}
			//insertall
				public List<Drivers> insertall(List<Drivers> drivers){
					return repo.saveAll(drivers);
				}
				
				public List<Drivers> findDrivers(){
					return repo.findAll();
					
				}
}
