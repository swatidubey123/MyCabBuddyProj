package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.pojo.Ride;
import com.example.demo.pojo.User;

public interface RideRepo extends JpaRepository<Ride, Integer> {

	/*
	 * //SELECT r.ride_id, r.ride_date_time, r.pickup_location, d.driver_name FROM
	 * Ride r, Drivers d, User u WHERE r.did = d.driver_id AND r.user_id = u.user_id
	 * AND r.user_id = 2;
	 * 
	 * String query1 =
	 * "SELECT r.ride_id,r.ride_date_time,r.pickup_location,d.driver_name from Ride r,Drivers d,User u where r.did = d.driver_id  AND r.user_id =?1 "
	 * ;
	 * 
	 * @Query(query1) public List<Object[]> viewAllRides(int user_id);
	 */
	/*
	 * String
	 * query1="select c.ride_id, c.ride_date_time,c.pickup_location, d.drivername from User_Driver_Map a, user_ride b, Ride c, Drivers d,User u where a.uid=b.uid and a.uid=c.user_id and u.user_id=?1"
	 * ;
	 * 
	 * @Query(query1) public List<Object []> findbyuserId(int user_id);
	 */
	// List<Ride> findByUserID(int user_id);

	// List<Ride> findByName(String name);

}
