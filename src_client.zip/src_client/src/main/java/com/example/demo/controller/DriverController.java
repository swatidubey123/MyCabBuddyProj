package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Drivers;
import com.example.demo.pojo.Ride;
import com.example.demo.pojo.User;
import com.example.demo.service.DriverService;

@RestController
public class DriverController {
	@Autowired 
	DriverService service;
	//insert
	@PostMapping("/insertDriver")             //JSON --> auto converted into the java object
	public Drivers insert(@RequestBody Drivers driver) {
		return service.insert(driver);
	}

	@PostMapping("/insertallDrivers")
	public List<Drivers> insertall(@RequestBody List<Drivers> driverList){
		return service.insertall(driverList);
	}
	
	
	
	@GetMapping("/getAllDriversClient")
	public List<Drivers> findAllDrivers(){
		return service.findDrivers();
	}
}
