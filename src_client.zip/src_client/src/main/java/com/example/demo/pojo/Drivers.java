package com.example.demo.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class Drivers {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int driver_id;
	//private int user_id;
	private String driver_name;
	
	private String availability_status;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="driver_user",
	//present class column or id 
	joinColumns = {@JoinColumn(name="did",referencedColumnName = "driver_id")},
	inverseJoinColumns = {@JoinColumn(name="uid",referencedColumnName = "user_id")}
			)
	List<User> users;

	 @OneToOne(cascade = CascadeType.ALL)
	 @JoinColumn(name="rid", referencedColumnName = "ride_id" )
	 private Ride ride;

	    
}
