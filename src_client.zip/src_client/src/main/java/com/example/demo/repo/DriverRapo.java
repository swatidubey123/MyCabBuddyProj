package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.Drivers;

public interface DriverRapo extends JpaRepository<Drivers, Integer>{

}
