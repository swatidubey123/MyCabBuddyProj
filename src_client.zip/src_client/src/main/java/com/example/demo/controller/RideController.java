package com.example.demo.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.pojo.Drivers;
import com.example.demo.pojo.Ride;
import com.example.demo.pojo.User;
import com.example.demo.service.RideService;

@Controller
public class RideController {
@Autowired 
RideService service;
Logger log=Logger.getAnonymousLogger();

//insert postman
/*
 * @PostMapping("/insertRide") //JSON --> auto converted into the java object
 * public Ride insert(@RequestBody Ride ride) { return service.insert(ride); }
 */
@ResponseBody
@RequestMapping("/bookRide/{pickup_location}/{destination}/{ride_date_time}/{fare}/{user_id}/{driver_id}")
public String register(HttpServletRequest request,HttpServletResponse
response,@PathVariable("pickup_location") String pickup_location,@PathVariable("destination") String
destination, @PathVariable("ride_date_time") String ride_date_time, @PathVariable("fare") String
fare, @PathVariable("user_id") String user_id,@PathVariable("driver_id") String driver_id) 
{
log.info("enetered into the register ms code ");
Ride ride=new Ride();
Drivers driver=new Drivers();
ride.setPickup_location(pickup_location); 
ride.setDestination(destination); 
ride.setRide_date_time(ride_date_time);
ride.setFare(Integer.parseInt(fare)); 
ride.setDriver_id(Integer.parseInt(driver_id));
User user=new User();
user.setUser_id(Integer.parseInt(user_id));
user.setName(request.getParameter("name"));
user.setEmail(request.getParameter("email"));
user.setPassword(request.getParameter("password"));
user.setPhno(request.getParameter("phno"));
user.setUserType(request.getParameter("userType"));
//driver.setDriver_id(Integer.parseInt(driver_id));


ride.setUser(user);

service.insert(ride); 
return "done";

}

@PostMapping("/insertallRides")
public List<Ride> insertall(@RequestBody List<Ride> rideList){
	return service.insertall(rideList);
}



/*
 * @ResponseBody
 * 
 * @RequestMapping("/ViewAllBooking/{user_id}") public String
 * register(HttpServletRequest request,HttpServletResponse
 * response,@PathVariable("user_id") String user_id) {
 * log.info("enetered into the ViewAllBooking clint ride controller code ");
 * User user=new User(); user.setUser_id(Integer.parseInt(user_id));
 * 
 * service.viewAllUserRides(user); return "done";
 * 
 * }
 */
/*
 * @GetMapping("/getRidebyuserId/{user_id}") public List<Object[]>
 * findbyuserId(@PathVariable("user_id") int user_id){ return
 * service.findbyuserId(user_id); }
 */
 
}
